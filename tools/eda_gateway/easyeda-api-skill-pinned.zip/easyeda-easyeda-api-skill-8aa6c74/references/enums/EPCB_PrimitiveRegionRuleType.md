# EPCB\_PrimitiveRegionRuleType enum

Region primitive region rule type

## Signature

```typescript
enum EPCB_PrimitiveRegionRuleType
```

## Enumeration Members

<table><thead><tr><th>

Member

</th><th>

Value

</th><th>

Description

</th></tr></thead>
<tbody><tr><td>

FOLLOW\_REGION\_RULE

</td><td>

`9`

</td><td>

约束区域

</td></tr>
<tr><td>

NO\_COMPONENTS

</td><td>

`2`

</td><td>

禁止元件

</td></tr>
<tr><td>

NO\_FILLS

</td><td>

`6`

</td><td>

禁止填充

</td></tr>
<tr><td>

NO\_INNER\_ELECTRICAL\_LAYERS

</td><td>

`8`

</td><td>

禁止内电层

</td></tr>
<tr><td>

NO\_POURS

</td><td>

`7`

</td><td>

禁止覆铜

</td></tr>
<tr><td>

NO\_WIRES

</td><td>

`5`

</td><td>

禁止布线

</td></tr>
</tbody></table>

## Remarks

[FOLLOW\_REGION\_RULE](./EPCB_PrimitiveRegionRuleType.md) is the constrained region