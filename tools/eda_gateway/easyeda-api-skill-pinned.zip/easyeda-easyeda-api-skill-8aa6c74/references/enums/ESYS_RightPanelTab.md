# ESYS\_RightPanelTab enum

> Warning: This API is now obsolete.
>
> 请使用 `ESYS_PanelTab` 替代 since EDA v4.2

Right panel tab

## Signature

```typescript
enum ESYS_RightPanelTab
```

## Enumeration Members

<table><thead><tr><th>

Member

</th><th>

Value

</th><th>

Description

</th></tr></thead>
<tbody><tr><td>

ANNOTATION

</td><td>

`'annotation'`

</td><td>

批注

</td></tr>
<tr><td>

PANEL\_3D\_PREVIEW\_ATTR

</td><td>

`'panel3d-attr'`

</td><td>

面板 3D 预览：属性

</td></tr>
<tr><td>

PANEL\_3D\_PREVIEW\_LAYER

</td><td>

`'panel3d-layer'`

</td><td>

面板 3D 预览：图层

</td></tr>
<tr><td>

PANEL\_ATTR

</td><td>

`'panel-attr'`

</td><td>

面板：属性

</td></tr>
<tr><td>

PANEL\_FILTER

</td><td>

`'panel-filter'`

</td><td>

面板：过滤

</td></tr>
<tr><td>

PANEL\_LAYER

</td><td>

`'panel-layer'`

</td><td>

面板：图层

</td></tr>
<tr><td>

PCB\_2D\_PREVIEW\_ATTR

</td><td>

`'pcb2d-attr'`

</td><td>

PCB 2D 预览：属性

</td></tr>
<tr><td>

PCB\_3D\_PREVIEW\_ATTR

</td><td>

`'pcb3d-attr'`

</td><td>

PCB 3D 预览：属性

</td></tr>
<tr><td>

PCB\_3D\_PREVIEW\_LAYER

</td><td>

`'pcb3d-layer'`

</td><td>

PCB 3D 预览：图层

</td></tr>
<tr><td>

PCB\_ATTR

</td><td>

`'pcb-attr'`

</td><td>

PCB：属性

</td></tr>
<tr><td>

PCB\_FILTER

</td><td>

`'pcb-filter'`

</td><td>

PCB：过滤

</td></tr>
<tr><td>

PCB\_LAYER

</td><td>

`'pcb-layer'`

</td><td>

PCB：图层

</td></tr>
<tr><td>

PCB\_SKETCHER\_ATTR

</td><td>

`'pcb-sketcher-attr'`

</td><td>

PCB：测量对象属性

</td></tr>
<tr><td>

PROJECT\_ATTR

</td><td>

`'project-attr'`

</td><td>

工程：属性

</td></tr>
<tr><td>

SCH\_ATTR

</td><td>

`'sch-attr'`

</td><td>

原理图：属性

</td></tr>
<tr><td>

SCH\_FILTER

</td><td>

`'sch-filter'`

</td><td>

原理图：过滤

</td></tr>
</tbody></table>