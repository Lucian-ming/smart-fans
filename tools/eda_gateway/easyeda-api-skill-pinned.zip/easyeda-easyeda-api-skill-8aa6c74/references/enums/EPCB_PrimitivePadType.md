# EPCB\_PrimitivePadType enum

Pad type

## Signature

```typescript
enum EPCB_PrimitivePadType
```

## Enumeration Members

<table><thead><tr><th>

Member

</th><th>

Value

</th><th>

Description

</th></tr></thead>
<tbody><tr><td>

MARK\_POINT

</td><td>

`2`

</td><td>

标识点

</td></tr>
<tr><td>

NORMAL

</td><td>

`0`

</td><td>

焊盘

</td></tr>
<tr><td>

TEST

</td><td>

`1`

</td><td>

测试点

</td></tr>
</tbody></table>