# ESCH\_PrimitiveFillStyle enum

Fill style

## Signature

```typescript
enum ESCH_PrimitiveFillStyle
```

## Enumeration Members

<table><thead><tr><th>

Member

</th><th>

Value

</th><th>

Description

</th></tr></thead>
<tbody><tr><td>

GRID

</td><td>

`'Grid'`

</td><td>

网格

</td></tr>
<tr><td>

HORIZONTAL\_LINE

</td><td>

`'Horizontal Line'`

</td><td>

横线

</td></tr>
<tr><td>

LEFT\_SLASH\_LINE

</td><td>

`'Left Slash Line'`

</td><td>

左斜线

</td></tr>
<tr><td>

NONE

</td><td>

`'None'`

</td><td>

无

</td></tr>
<tr><td>

RHOMBIC\_GRID

</td><td>

`'Rhombic Grid'`

</td><td>

菱形网格

</td></tr>
<tr><td>

RIGHT\_SLASH\_LINE

</td><td>

`'Right Slash Line'`

</td><td>

右斜线

</td></tr>
<tr><td>

SOLID

</td><td>

`'Solid'`

</td><td>

实心

</td></tr>
<tr><td>

VERTICAL\_LINE

</td><td>

`'Vertical Line'`

</td><td>

竖线

</td></tr>
</tbody></table>