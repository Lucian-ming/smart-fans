# ESYS\_HeaderMenuEnvironment enum

Header menu environment

## Signature

```typescript
enum ESYS_HeaderMenuEnvironment
```

## Enumeration Members

<table><thead><tr><th>

Member

</th><th>

Value

</th><th>

Description

</th></tr></thead>
<tbody><tr><td>

BLANK

</td><td>

`'blank'`

</td><td>

空白页

</td></tr>
<tr><td>

FOOTPRINT

</td><td>

`'footprint'`

</td><td>

封装

</td></tr>
<tr><td>

HOME

</td><td>

`'home'`

</td><td>

主页

</td></tr>
<tr><td>

PANEL

</td><td>

`'panel'`

</td><td>

面板

</td></tr>
<tr><td>

PANEL\_LIBRARY

</td><td>

`'panelLibrary'`

</td><td>

面板库

</td></tr>
<tr><td>

PANEL\_VIEW

</td><td>

`'panelView'`

</td><td>

面板预览

</td></tr>
<tr><td>

PCB

</td><td>

`'pcb'`

</td><td>

PCB

</td></tr>
<tr><td>

PCB\_VIEW

</td><td>

`'pcbView'`

</td><td>

PCB 预览（包括 2D、3D 预览）

</td></tr>
<tr><td>

SCHEMATIC

</td><td>

`'sch'`

</td><td>

原理图

</td></tr>
<tr><td>

SIMULATION\_SCHEMATIC\_NGSPICE

</td><td>

`'simulationSchematicNgspice'`

</td><td>

仿真原理图：Ngspice

</td></tr>
<tr><td>

SIMULATION\_SCHEMATIC\_SIMULIDE

</td><td>

`'simulationSchematicSimulIDE'`

</td><td>

仿真原理图：SimulIDE

</td></tr>
<tr><td>

SYMBOL

</td><td>

`'symbol'`

</td><td>

符号（包括 CBB 符号）

</td></tr>
</tbody></table>