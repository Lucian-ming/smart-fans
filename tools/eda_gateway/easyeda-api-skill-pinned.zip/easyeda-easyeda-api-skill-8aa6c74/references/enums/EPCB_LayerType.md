# EPCB\_LayerType enum

Layer type

## Signature

```typescript
enum EPCB_LayerType
```

## Enumeration Members

<table><thead><tr><th>

Member

</th><th>

Value

</th><th>

Description

</th></tr></thead>
<tbody><tr><td>

ASSEMBLY

</td><td>

`'ASSEMBLY'`

</td><td>

装配层

</td></tr>
<tr><td>

CUSTOM

</td><td>

`'CUSTOM'`

</td><td>

自定义层

</td></tr>
<tr><td>

INTERNAL\_ELECTRICAL

</td><td>

`'PLANE'`

</td><td>

内电层

</td></tr>
<tr><td>

OTHER

</td><td>

`'OTHER'`

</td><td>

其它

</td></tr>
<tr><td>

PASTE\_MASK

</td><td>

`'PASTE_MASK'`

</td><td>

锡膏（助焊）层

</td></tr>
<tr><td>

SIGNAL

</td><td>

`'SIGNAL'`

</td><td>

信号层

</td></tr>
<tr><td>

SILKSCREEN

</td><td>

`'SILKSCREEN'`

</td><td>

丝印层

</td></tr>
<tr><td>

SOLDER\_MASK

</td><td>

`'SOLDER_MASK'`

</td><td>

阻焊层

</td></tr>
</tbody></table>