# ESCH\_PrimitiveTextAlignMode enum

Text alignment mode

## Signature

```typescript
enum ESCH_PrimitiveTextAlignMode
```

## Enumeration Members

<table><thead><tr><th>

Member

</th><th>

Value

</th><th>

Description

</th></tr></thead>
<tbody><tr><td>

CENTER

</td><td>

`5`

</td><td>

中心

</td></tr>
<tr><td>

CENTER\_BOTTOM

</td><td>

`6`

</td><td>

中下

</td></tr>
<tr><td>

CENTER\_TOP

</td><td>

`4`

</td><td>

中上

</td></tr>
<tr><td>

LEFT\_BOTTOM

</td><td>

`3`

</td><td>

左下

</td></tr>
<tr><td>

LEFT\_MIDDLE

</td><td>

`2`

</td><td>

左中

</td></tr>
<tr><td>

LEFT\_TOP

</td><td>

`1`

</td><td>

左上

</td></tr>
<tr><td>

RIGHT\_BOTTOM

</td><td>

`9`

</td><td>

右下

</td></tr>
<tr><td>

RIGHT\_MIDDLE

</td><td>

`8`

</td><td>

右中

</td></tr>
<tr><td>

RIGHT\_TOP

</td><td>

`7`

</td><td>

右上

</td></tr>
</tbody></table>