# ImageProps interface

图片组件：展示单张图片

## Signature

```typescript
interface ImageProps
```

## Properties

<table><thead><tr><th>

Property

</th><th>

Modifiers

</th><th>

Type

</th><th>

Description

</th></tr></thead>
<tbody><tr><td>

[onClick?](./ImageProps.md)

</td><td>

</td><td>

() =&gt; void

</td><td>

_(Optional)_ 点击图片时触发

</td></tr>
<tr><td>

[src](./ImageProps.md)

</td><td>

</td><td>

string

</td><td>

Image URL (required)

</td></tr>
<tr><td>

[title?](./ImageProps.md)

</td><td>

</td><td>

string

</td><td>

_(Optional)_ Image title (alt/text)

</td></tr>
</tbody></table>

---

## 属性详情

### onclick

# ImageProps.onClick property

点击图片时触发

## Signature

```typescript
onClick?: () => void;
```

### src

# ImageProps.src property

Image URL (required)

## Signature

```typescript
src: string;
```

### title

# ImageProps.title property

Image title (alt/text)

## Signature

```typescript
title?: string;
```
