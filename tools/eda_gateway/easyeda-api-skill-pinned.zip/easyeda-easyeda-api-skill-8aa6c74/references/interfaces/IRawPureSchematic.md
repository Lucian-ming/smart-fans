# IRawPureSchematic interface

原始数据 - pureSchematic

## Signature

```typescript
interface IRawPureSchematic
```

## Properties

<table><thead><tr><th>

Property

</th><th>

Modifiers

</th><th>

Type

</th><th>

Description

</th></tr></thead>
<tbody><tr><td>

[nlNetWires](./IRawPureSchematic.md)

</td><td>

</td><td>

Array&lt;[IRawNet](./IRawNet.md)<!-- -->&gt;

</td><td>

</td></tr>
<tr><td>

[sheets](./IRawPureSchematic.md)

</td><td>

</td><td>

\{ \[uuid: string\]: \{ uuid: string; title: string; displayTitle: string; zIndex: number \} \}

</td><td>

</td></tr>
</tbody></table>

---

## 属性详情

### nlnetwires

# IRawPureSchematic.nlNetWires property

## Signature

```typescript
nlNetWires: Array<IRawNet>;
```

### sheets

# IRawPureSchematic.sheets property

## Signature

```typescript
sheets: { [uuid: string]: { uuid: string; title: string; displayTitle: string; zIndex: number } };
```
